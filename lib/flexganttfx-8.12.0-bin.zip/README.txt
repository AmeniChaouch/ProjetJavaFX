Homepage: http://www.dlsc.com

This is the FlexGanttFX distribution. It contains the following items:

-- manual.pdf

   The developer manual exported from the product's WIKI pages. The online version
   can be found at:

        https://flexgantt.atlassian.net/wiki/display/FFXMAN/FlexGanttFX+Developer+Manual

-- docs

   Contains the generated JavaDocs / API HTML files. 
   
-- ext

   Contains third party libraries that are needed for running FlexGanttFX.
   
-- legal

	The available licensing agreements (development, runtime, source, research)
	
-- lib

	The actual FlexGanttFX libraries (core, model, view, extras).
	
-- tutorial

	Contains an example file to get you started.
	
Questions? Need Help? Contact me via dlsc.com

Dirk Lemmermann
https://www.dlsc.com
Twitter: dlemmermann
Mobile: +41-79-800-23-20


