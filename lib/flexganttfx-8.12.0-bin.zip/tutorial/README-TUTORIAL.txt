The tutorial is still work-in-progress. It currently only contains a single 
example file with an Aircraft / Flight scenario. To compile it create a new project
in your preferred IDE, add the JAR files found in the lib folder to the classpath,
add the TutorialAircraftFlight.java file to your source folder.

Please make sure to use Java 8.